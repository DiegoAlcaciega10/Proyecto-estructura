var searchData=
[
  ['serializar_0',['serializar',['../class_cita.html#abb943e3efbf037984f2b37ff291607bf',1,'Cita::serializar()'],['../class_fecha.html#af2f540b1826b4cae0d2c08e92528f4e2',1,'Fecha::serializar()'],['../class_hora.html#a82c78bc5f58d68def3742a8f0461edc2',1,'Hora::serializar()'],['../class_paciente.html#a1c995399601653f7918b6285d920df3f',1,'Paciente::serializar()'],['../class_persona.html#a817c73f3687bbaf12dd76f06eaa5ff4d',1,'Persona::serializar()']]],
  ['setanio_1',['setAnio',['../class_fecha.html#a47ca2f1ef1c7e07efab00927a8864843',1,'Fecha']]],
  ['setcedula_2',['setCedula',['../class_persona.html#a587b9b8ceec611f84681bdd14fe33698',1,'Persona']]],
  ['setdia_3',['setDia',['../class_fecha.html#ae65d70b4f4a3230bd569fd64146fd018',1,'Fecha']]],
  ['setespecialidad_4',['setEspecialidad',['../class_cita.html#a7d7fe23578f510ded64d5b0ff27581ec',1,'Cita']]],
  ['setfecha_5',['setFecha',['../class_cita.html#aba1ed34baf8c29dc88a0412ac0993368',1,'Cita']]],
  ['setfechanacimiento_6',['setFechaNacimiento',['../class_persona.html#ae108f69625efc44498554d40dbc66036',1,'Persona']]],
  ['sethistorialmedico_7',['setHistorialMedico',['../class_paciente.html#a58afef1dd5b515c9146df30c3a400c74',1,'Paciente']]],
  ['sethora_8',['setHora',['../class_cita.html#a8ec05e2322eb4b9d33d7c8d828438f37',1,'Cita::setHora()'],['../class_hora.html#a35403074ace8cb745ef751184228c202',1,'Hora::setHora()']]],
  ['setmes_9',['setMes',['../class_fecha.html#aff02d2faaa981e2986cda85d45a0b525',1,'Fecha']]],
  ['setminuto_10',['setMinuto',['../class_hora.html#a39bb851693738bee48a8fb72317d2955',1,'Hora']]],
  ['setmotivo_11',['setMotivo',['../class_cita.html#a9824b0b18b923b83cbcc18b7f6e9aae9',1,'Cita']]],
  ['setnombre_12',['setNombre',['../class_persona.html#a830e698682a31607d518556945a6cb09',1,'Persona']]],
  ['setpaciente_13',['setPaciente',['../class_cita.html#abcd370ac61e66d03cd70a6233d16b9c5',1,'Cita']]],
  ['setsegundo_14',['setSegundo',['../class_hora.html#af0298250f35dc1ae8a6b7a4de372ea28',1,'Hora']]]
];
