var searchData=
[
  ['paciente_0',['Paciente',['../class_paciente.html#af237f045043da3947ae7f328eed8289d',1,'Paciente']]],
  ['persona_1',['Persona',['../class_persona.html#a3f7e286c137152f539392e39278d664f',1,'Persona']]]
];
