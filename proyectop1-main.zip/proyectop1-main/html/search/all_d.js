var searchData=
[
  ['realizarbackup_0',['realizarBackup',['../class_gestor_citas.html#a41351f8628d8e9b0fedc479ec7675a42',1,'GestorCitas']]],
  ['restaurardesdebackup_1',['restaurarDesdeBackup',['../class_gestor_citas.html#a93b6fa0a87e75fad62c625eec7c94ede',1,'GestorCitas']]]
];
