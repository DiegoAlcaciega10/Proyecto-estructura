var searchData=
[
  ['paciente_0',['Paciente',['../class_paciente.html',1,'']]],
  ['persona_1',['Persona',['../class_persona.html',1,'']]]
];
