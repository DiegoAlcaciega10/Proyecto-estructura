var searchData=
[
  ['paciente_2eh_0',['Paciente.h',['../_paciente_8h.html',1,'']]],
  ['persona_2eh_1',['Persona.h',['../_persona_8h.html',1,'']]]
];
