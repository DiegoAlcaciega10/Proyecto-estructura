var searchData=
[
  ['hora_0',['Hora',['../class_hora.html#ac2d6f1b994e7d50f3ae08436f13c7bfb',1,'Hora::Hora(int h=-1, int m=-1, int s=-1)'],['../class_hora.html#a4bdbe5d5df44f5ff151578232d249e9b',1,'Hora::Hora(const Hora &amp;otra)']]]
];
