var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_fecha.html#a8bbe7d2a8e70d4d42d9e406b6aa617fe',1,'Fecha::operator&lt;&lt;()'],['../class_hora.html#ac672fa5834eb56243a71f2c97e74cd82',1,'Hora::operator&lt;&lt;()']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_fecha.html#a443140e62287a8efbe3f7976c268b4ec',1,'Fecha::operator&gt;&gt;()'],['../class_hora.html#a271a3f12e93428c5d8ed88e6ea7e1dd7',1,'Hora::operator&gt;&gt;()']]]
];
