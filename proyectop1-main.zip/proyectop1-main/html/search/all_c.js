var searchData=
[
  ['paciente_0',['Paciente',['../class_paciente.html',1,'Paciente'],['../class_paciente.html#af237f045043da3947ae7f328eed8289d',1,'Paciente::Paciente()']]],
  ['paciente_2eh_1',['Paciente.h',['../_paciente_8h.html',1,'']]],
  ['persona_2',['Persona',['../class_persona.html',1,'Persona'],['../class_persona.html#a3f7e286c137152f539392e39278d664f',1,'Persona::Persona()']]],
  ['persona_2eh_3',['Persona.h',['../_persona_8h.html',1,'']]]
];
