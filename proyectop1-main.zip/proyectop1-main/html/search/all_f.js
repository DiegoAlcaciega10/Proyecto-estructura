var searchData=
[
  ['_7egestorcitas_0',['~GestorCitas',['../class_gestor_citas.html#a96a584429f3b87b9804d6704415b0bef',1,'GestorCitas']]],
  ['_7epersona_1',['~Persona',['../class_persona.html#a6054c4b887594e8748771598fa734044',1,'Persona']]]
];
